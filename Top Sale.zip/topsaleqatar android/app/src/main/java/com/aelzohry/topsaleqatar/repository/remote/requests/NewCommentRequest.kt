package com.aelzohry.topsaleqatar.repository.remote.requests

class NewCommentRequest(
    val ad: String,
    val text: String
)