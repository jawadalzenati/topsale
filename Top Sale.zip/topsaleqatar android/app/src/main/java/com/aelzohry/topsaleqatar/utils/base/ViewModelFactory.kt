package com.aelzohry.topsaleqatar.utils.base

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider

/*
* created by : ahmed mustafa
* email : ahmed.mustafa15996@gmail.com
*phone : +201025601465
*/
//class ViewModelFactory(private val id: Int, private val txt: String? = null) :
//    ViewModelProvider.NewInstanceFactory() {
//    override fun <T : ViewModel?> create(modelClass: Class<T>): T {
//
//
//        return
////        when {
////            modelClass.isAssignableFrom(ProductDetailsViewModel::class.java) -> ProductDetailsViewModel(
////                productId = id
////            ) as T
////            modelClass.isAssignableFrom(OrderDetailsViewModel::class.java) -> OrderDetailsViewModel(
////                orderId = id
////            ) as T
////            else -> super.create(modelClass)
////        }
//
//    }
//}