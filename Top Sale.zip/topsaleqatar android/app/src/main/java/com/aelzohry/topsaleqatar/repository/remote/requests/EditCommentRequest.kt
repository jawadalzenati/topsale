package com.aelzohry.topsaleqatar.repository.remote.requests

class EditCommentRequest(
    val text: String
)