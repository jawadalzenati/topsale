package com.aelzohry.topsaleqatar.repository.remote.requests

class ReportAdRequest(
    val text: String
)