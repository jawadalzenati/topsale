package com.aelzohry.topsaleqatar.repository.remote.requests

class NewChannelRequest(
    val ad: String?,
    val user: String?
)