package com.aelzohry.topsaleqatar.ui.comments

import com.aelzohry.topsaleqatar.utils.base.BaseViewModel

/*
* created by : ahmed mustafa
* email : ahmed.mustafa15996@gmail.com
*phone : +201025601465
*/
class CommentViewModel  :BaseViewModel() {
}