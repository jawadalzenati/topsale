package com.aelzohry.topsaleqatar.repository.remote.requests

class NewMessageTextRequest(
    val text: String
)